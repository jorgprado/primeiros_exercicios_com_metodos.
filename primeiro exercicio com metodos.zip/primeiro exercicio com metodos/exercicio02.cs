/*Exercício 2: Escreva um programa que leia dois valores reais e apresente a diferença do maior
para o menor. Um método chamado diferenca deverá ser implementado para realizar o cálculo e exibir
o resultado.*/

using System;
class Program{
    static void Main(String [] args){
    int n1, n2;
    Console.Write("digite um número: ");
    n1 = int.Parse(Console.ReadLine());
    Console.Write("Digite outro valor: ");
    n2 = int.Parse(Console.ReadLine());
    diferenca(n1,n2);


    }
    static void diferenca(int val1, int val2){
        int res;
        if (val1>val2){
            res = val1-val2;
        }
        else{
            res = val2-val1;
        }
        Console.WriteLine("a diferença entre {0} e {1} é {2}", val1, val2, res);
    }
}