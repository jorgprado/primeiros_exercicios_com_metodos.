    /*Exercício 1: Escreva um programa que calcule o fatorial de um número informado pelo usuário. 
Um método chamado calcularFatorial deverá retornar o resultado final. 
Dica: O fatorial de um número N é dado pela fórmula: N! = 1 * 2 * 3 * 4 * 5 * ... * N*/

using System;
class Program{
    static void Main(string [] args){
        int n;
        double r;
        Console.Write("digite um numero: ");
        n=int.Parse(Console.ReadLine());
        r = calcularFatorial(n);
        Console.WriteLine("\nO fatorial do número escolhido é "+r);
    }
        static double calcularFatorial(int num){
    double res = 1;
    while (num != 1)
        {
        res = res * num;
        num = num - 1;
        }
    return res;
}
}

