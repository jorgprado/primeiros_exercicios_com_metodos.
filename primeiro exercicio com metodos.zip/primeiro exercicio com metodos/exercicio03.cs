/*Exercício 3: Escreva um programa que leia três valores para os lados de um triângulo
 (variáveis A, B e C). Verificar se cada lado é menor que a soma dos outros dois lados. 
 Se sim, saber de A==B e se B==C, sendo verdade o triângulo é equilátero; 
 Se não, verificar de A==B ou se A==C ou se B==C, sendo verdade o triângulo é isósceles; 
 e caso contrário, o triângulo será escaleno. Caso os lados fornecidos não caracterizarem um triângulo,
  avisar a ocorrência. Deverá ser implementado um método para verificar a validade de cada tipo de
   triângulo. Estes métodos deverão retornar um valor lógico (true ou false). */

using System;
class Program
    {
        static void Main(string[] args) {

            int A, B, C;

            Console.WriteLine("Verificador de Triângulo\n\n");


            Console.WriteLine("Digite o lado A=");
            A = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite o lado B=");
            B = int.Parse(Console.ReadLine());
            Console.WriteLine("Digite o lado C=");
            C = int.Parse(Console.ReadLine());

            Console.WriteLine( equilatero(A, B, C));

            Console.ReadKey();
        }
        public static bool equilatero(int A, int B, int C)
        {
            bool resp = false;

            if (A < B + C && B < A + C && C < A + B)
            {                
                if (A == B && B == C)
                {
                    Console.WriteLine("O triângulo é Eqüilátero.");
                    resp = true;
                }
                else if (A == B || A == C || B == C)
                {
                    Console.WriteLine("O triângulo é Isósceles.");
                    resp = true;
                }
                else
                {
                    Console.WriteLine("O triângulo é Escaleno.");
                    resp = true;
                }
            }
            else
            {
                Console.WriteLine("Os lados fornecidos não caracterizam um triângulo");
            }
            return resp;
        }
    }
}