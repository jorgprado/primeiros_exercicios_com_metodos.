/*Exercício 4: Tendo como dados de entrada a altura e o sexo de uma pessoa, faça um programa que calcule
 o peso ideal, utilizando as seguintes fórmulas: (h = altura) 
- Para homens: (72.7*h) - 58 
- Para mulheres: (62.1 *h) - 44.7 
Um método chamado calcularPesoIdeal deverá ser implementado para a realização do cálculo,
 sendo que deverá receber por parâmetro o sexo e a altura da pessoa.*/

 using System;
class Program
{
    static void Main(string [] args)
    {
        string s;
        double h;
        double r;
        Console.WriteLine("Digite seu Sexo 'F' para Feminino e 'M' para Masculino: ");
        s = Console.ReadLine();
        Console.WriteLine("Digite ua altura: ");
        h = double.Parse(Console.ReadLine());
        r = pesoI(s,h);
        Console.WriteLine("Seu peso Ideial é "+r);

    }

    static double pesoI(string sexo, double altura){
        double res = 0;
        if (sexo == "F")
        {
            res = (62.1 *altura) - 44.7;
        }
        else if (sexo == "M")
        {
            res = (72.7*altura) - 58;
        }
        else
        {
            Console.WriteLine("Digite uma das duas Opções!!");
        }
        return res;
        }
}