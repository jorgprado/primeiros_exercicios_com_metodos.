/*Exercício 5: Escreva um programa que exiba o seguinte menu e crie um método para realizar os cálculos
 de cada item deste menu: 
1 – Soma 
2 – Subtração 
3 – Divisão 
4 – Multiplicação 
5 – Resto da Divisão 
6 – Dobro 
7 – Quadrado 
8 – Cubo 
9 – Raiz Quadrada 
0 – Sair 
*/

using System;
    class Program
    {
        static void Main(string[] args)
        {
            int v;

            do
            {
                Console.WriteLine("\nO que deseja fazer ?\nSomar (1)\nSubtrair (2)\nDividir (3)\nMultplicação (4)\nResto da Divisão (5)\nDobro (6)\nQuadrado (7)\nCubo (8)\nRaiz Quadrada (9)\nSair (0)\n");
                v = int.Parse(Console.ReadLine());
                switch (v)
                {
                    case 1:
                        Soma();
                        break;
                    case 2:
                        Subtrair();
                        break;
                    case 3:
                        Divisao();
                        break;
                    case 4:
                        Multplicacao();
                        break;
                    case 5:
                        RestoDiv();
                        break;
                    case 6:
                        Dobro();
                        break;
                    case 7:
                        Quadrado();
                        break;
                    case 8:
                        Cubo();
                        break;
                    case 9:
                        RaizQuadrada();
                        break;
                }
            } while (v != 0);

        }
        static void Soma()
        {
            double res,y,x;

            Console.WriteLine("Digite um numero aqui");
            x = double.Parse(Console.ReadLine());
            Console.WriteLine("Digite com qual número deseja somar");
            y = double.Parse(Console.ReadLine());
            res = x + y;
            Console.WriteLine("O resultado é: " + res);
            Console.ReadKey();
        }
        static void Subtrair()
        {
            double res, y, x;

            Console.WriteLine("Digite um numero aqui");
            x = double.Parse(Console.ReadLine());
            Console.WriteLine("Digite com qual número deseja subtrair");
            y = double.Parse(Console.ReadLine());
            res = x - y;
            Console.WriteLine("O resultado é: " + res);
            Console.ReadKey();
        }
        static void Divisao()
        {
            double res, y, x;

            Console.WriteLine("Digite um numero aqui ");
            x = double.Parse(Console.ReadLine());
            Console.WriteLine("Digite com qual número deseja dividir");
            y = double.Parse(Console.ReadLine());
            res = x / y;
            Console.WriteLine("O resultado é: " + res);
            Console.ReadKey();
        }
        static void Multplicacao()
        {
            double res, y, x;

            Console.WriteLine("Digite um numero aqui");
            x = double.Parse(Console.ReadLine());
            Console.WriteLine("Digite com qual número deseja multplicar");
            y = double.Parse(Console.ReadLine());
            res = x * y;
            Console.WriteLine("O resultado é: " + res);
            Console.ReadKey();
        }
        static void RestoDiv()
        {
            double res, y, x;

            Console.WriteLine("Digite um numero aqui");
            x = double.Parse(Console.ReadLine());
            Console.WriteLine("Digite outro numero");
            y = double.Parse(Console.ReadLine());
            res = x % y;
            Console.WriteLine("O resultado é: " + res);
            Console.ReadKey();
        }
        static void Dobro()
        {
            double res, x;

            Console.WriteLine("Digite um numero aqui");
            x = double.Parse(Console.ReadLine());
            res = x * 2;
            Console.WriteLine("O resultado é: " + res);
            Console.ReadKey();
        }
        static void Quadrado()
        {
            double res, x;

            Console.WriteLine("Digite um numero aqui");
            x = double.Parse(Console.ReadLine());
            res = Math.Pow(x,2);
            Console.WriteLine("O resultado é: " + res);
            Console.ReadKey();
        }
        static void Cubo()
        {
            double res, x;

            Console.WriteLine("Digite um numero aqui");
            x = double.Parse(Console.ReadLine());
            res = Math.Pow(x, 3);
            Console.WriteLine("O resultado é: " + res);
            Console.ReadKey();
        }
        static void RaizQuadrada()
        {
            double res, x;

            Console.WriteLine("Digite um numero aqui");
            x = double.Parse(Console.ReadLine());
            res = Math.Sqrt(x);
            Console.WriteLine("O resultado é: " + res);
            Console.ReadKey();
        }
    }